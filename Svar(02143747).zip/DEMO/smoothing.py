import h5py
import os
import numpy as np
import matplotlib.pyplot as plt
from mpl_toolkits.mplot3d import Axes3D
from scipy.interpolate import interp1d


def smooth_trajectory(data, num_points=1000):
    timesteps = np.linspace(0, 1, len(data))  
    interp_func = interp1d(timesteps, data, axis=0,
                           kind="linear", fill_value="extrapolate")

    new_timesteps = np.linspace(0, 1, num_points)

    return interp_func(new_timesteps)


def process_and_save_smoothed_data(directory, save_directory):

    h5_files = [os.path.join(directory, f)
                for f in os.listdir(directory) if f.endswith(".h5")]

    if not os.path.exists(save_directory):
        os.makedirs(save_directory)

    for file_path in h5_files:
        with h5py.File(file_path, "r") as f:
            data_group = f["data"]

            # Check available datasets
            datasets_to_smooth = [key for key in data_group.keys()]

            smoothed_data = {}

            for dataset_name in datasets_to_smooth:
                # Load dataset
                dataset = np.array(data_group[dataset_name])

                if dataset.ndim > 2:
                    # Flatten extra dimensions
                    dataset = dataset.reshape(dataset.shape[0], -1)

                smoothed_dataset = smooth_trajectory(dataset)

                smoothed_data[dataset_name] = smoothed_dataset

            file_name = os.path.basename(
                file_path).replace(".h5", "_smoothed.h5")
            save_path = os.path.join(save_directory, file_name)

            # Save smoothed data
            with h5py.File(save_path, "w") as new_h5:
                smoothed_group = new_h5.create_group("smoothed_data")
                for dataset_name, data in smoothed_data.items():
                    smoothed_group.create_dataset(dataset_name, data=data)

            print(f"Smoothed data saved to: {save_path}")


h5_directory = r"robosuite/DEMO/recorded_demo"
save_directory = r"robosuite/DEMO/smoothed_demo"

# ✅ Run the smoothing and save the results
process_and_save_smoothed_data(h5_directory, save_directory)