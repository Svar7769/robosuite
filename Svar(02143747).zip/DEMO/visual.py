import h5py
import numpy as np
import matplotlib.pyplot as plt
from mpl_toolkits.mplot3d import Axes3D
import os


def plot_all_trajectories(directory, use_smoothed=False):

    h5_files = [os.path.join(directory, f)
                for f in os.listdir(directory) if f.endswith(".h5")]


    fig = plt.figure(figsize=(12, 8))
    ax = fig.add_subplot(111, projection='3d')

    colors = ["red", "blue", "green", "orange", "purple"]

    for idx, file_path in enumerate(h5_files):
        with h5py.File(file_path, "r") as f:
            data_group_name = "smoothed_data" if use_smoothed else "data"

            data_group = f[data_group_name]

            # Load datasets
            robot_states = np.array(data_group["robot_states"])
            cube_states = np.array(data_group["cube_states"])

            if robot_states.ndim > 2:
                robot_states = robot_states.reshape(-1, 3)
            if cube_states.ndim > 2:
                cube_states = cube_states.reshape(-1, 3)

            color = colors[idx % len(colors)]

            # Plot end-effector trajectory
            ax.plot(robot_states[:, 0], robot_states[:, 1], robot_states[:, 2],
                    color=color, linestyle="-", label=f"EE Trajectory ({os.path.basename(file_path)})")
            ax.scatter(robot_states[0, 0], robot_states[0, 1], robot_states[0, 2],
                       color="black", s=30, label=f"Start EE ({os.path.basename(file_path)})")
            ax.scatter(robot_states[-1, 0], robot_states[-1, 1], robot_states[-1, 2],
                       color="red", s=30, label=f"End EE ({os.path.basename(file_path)})")

            # Plot cube positions
            ax.scatter(cube_states[:, 0], cube_states[:, 1], cube_states[:, 2],
                       color="blue", s=15, label=f"Cube Positions ({os.path.basename(file_path)})")

    # Labels & Equal Axis Scaling
    ax.set_xlabel("X [m]")
    ax.set_ylabel("Y [m]")
    ax.set_zlabel("Z [m]")
    ax.set_title("3D Trajectories of Robot End-Effector and Cube Positions")

    # Set equal aspect ratio for all axes
    max_range = np.array([robot_states[:, 0].max() - robot_states[:, 0].min(),
                          robot_states[:, 1].max() - robot_states[:, 1].min(),
                          robot_states[:, 2].max() - robot_states[:, 2].min()]).max() / 2.0

    mid_x = (robot_states[:, 0].max() + robot_states[:, 0].min()) * 0.5
    mid_y = (robot_states[:, 1].max() + robot_states[:, 1].min()) * 0.5
    mid_z = (robot_states[:, 2].max() + robot_states[:, 2].min()) * 0.5
    ax.set_xlim(mid_x - max_range, mid_x + max_range)
    ax.set_ylim(mid_y - max_range, mid_y + max_range)
    ax.set_zlim(mid_z - max_range, mid_z + max_range)

    ax.legend()
    plt.show()


h5_directory = r"robosuite/DEMO/recorded_demo"
smoothed_directory = r"robosuite/DEMO/smoothed_demo"

plot_all_trajectories(smoothed_directory,
                      use_smoothed=True)  # For smoothed data

plot_all_trajectories(h5_directory,
                      use_smoothed=False)  # For Raw data
