import h5py
import robosuite as suite
import numpy as np
import time
import pygame
import os
import cv2  

pygame.init()
screen = pygame.display.set_mode((300, 300))

USE_SMOOTHED = False  # Set True for "smoothed_data"

demo_dir = r"robosuite/DEMO/smoothed_demo" if USE_SMOOTHED else r"robosuite/DEMO/recorded_demo"

h5_files = [os.path.join(demo_dir, f)
            for f in os.listdir(demo_dir) if f.endswith(".h5")]

demo_file = max(h5_files, key=os.path.getmtime)
print(f"Using demonstration file: {demo_file}")

dataset_group = "smoothed_data" if USE_SMOOTHED else "data"

with h5py.File(demo_file, "r") as f:

    actions = np.array(f[f"{dataset_group}/actions"])
    joint_angles = np.array(f[f"{dataset_group}/joint_angles"])
    cube_states = np.array(f[f"{dataset_group}/cube_states"])

    num_steps = min(len(actions), len(joint_angles), len(cube_states))
    print(f"Loaded demonstration with {num_steps} steps.")

env = suite.make(
    env_name="Lift",  
    robots="UR5e", 
    has_renderer=True,
    has_offscreen_renderer=True,  
    use_camera_obs=True,  
    control_freq=20,
    hard_reset=False,
    camera_names="frontview", 
    camera_heights=512,  
    camera_widths=512
)

video_filename = "simulation_replay.mp4"
video_fps = 20  
video_size = (512, 512)  

fourcc = cv2.VideoWriter_fourcc(*"mp4v")
video_out = cv2.VideoWriter(video_filename, fourcc, video_fps, video_size)

env.reset()

expected_qpos = env.sim.model.nq
expected_qvel = env.sim.model.nv

env.sim.data.qpos[:] = joint_angles[0][:expected_qpos]
env.sim.data.qvel[:] = joint_angles[0][expected_qpos:]
env.sim.forward()

print("Press ESC to stop replay.")

for step in range(num_steps):
    for event in pygame.event.get():
        if event.type == pygame.KEYDOWN and event.key == pygame.K_ESCAPE:
            print("Exiting replay...")
            env.close()
            pygame.quit()
            video_out.release()
            exit()

    # cube_position = cube_states[step][:3]  
    # cube_orientation = cube_states[step][3:]  
    # env.sim.data.set_mocap_pos("cube_main", cube_position)
    # env.sim.data.set_mocap_quat("cube_main", cube_orientation)
    # env.sim.forward()

    env.sim.data.qpos[:] = joint_angles[step][:expected_qpos]
    env.sim.data.qvel[:] = joint_angles[step][expected_qpos:]
    env.sim.forward()

    obs, reward, done, _ = env.step(actions[step])

    frame = obs["frontview_image"]  # Capture rendered frame
    frame = cv2.cvtColor(frame, cv2.COLOR_RGB2BGR)
    video_out.write(frame) 

    env.render()
    time.sleep(1 / video_fps) 

video_out.release()
print(f"Replay complete! Video saved as {video_filename}")

env.close()
pygame.quit()
